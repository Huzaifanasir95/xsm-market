# Logo Placeholder

Place your "logo.png" file in this folder. The logo will be displayed in place of "XSM Market" text on the home page.

Recommended dimensions: 200px × 80px with transparent background.
